#!/bin/bash
unit_place=("" one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen)
tenth_place=("" "" twenty thirty forty fifty sixty seventy eighty ninty)
cr=10000000 # cr = 1 crore
lk=100000	# lk = 1 lakh
th=1000		# th = 1 thousand
hnd=100
twenty=20
one=1
zero=0
#echo "Enter the number"
#read a
read num
b=${#num}
regex='^[0-9]*$' #regular expression for checking the sequence of non negative number
				 # including the leading zero
if ! [[ $num =~ $regex ]];then
	echo "invalid input"
	exit -1
else 
        d=${#num} # length of the number seq.
        s='^[1-9]$' #regex for a single positive digit
        flg=$zero
        if ! [ "$d" -eq "1" ];then
        for ((i=0;i<d;i++))
        do
            ch=${num:$i:1} #character at ith index
            if [[ $ch =~ $s ]]; #if ch is a positive digit
            then
                    flg=$one
                    num=${num:$i}
                	break;
            fi
        done
        if [ "$flg" -eq "$zero" ];then #if flg == 0 then num was seq. of zeros
            num=$zero
        fi
 fi
        if [ "${#num}" -gt "11" ];then
            echo "invalid input"
            exit 1
        fi
fi
#assumed that num is well formatted
len=${#num}
if [ "$len" -eq "$one" ];then 
	if [ "$num" -ne "$zero" ];then 
		echo ${unit_place[$num]}
	else
		echo $zero
	fi 
	exit 0	
fi
if [ "$num" -ge "$cr" ];then
	n1=$(($num/$cr))
	if [ "$n1" -ge "$hnd" ];then
		if [ "$n1" -gt "$th" ];then
			echo -n ${unit_place[$(($n1/$th))]} thousand" "
			n1=$(($n1%$th))
		fi
		#n1 is in 999 and $hnd inclusive
		echo -n ${unit_place[$(($n1/$hnd))]} hundred" "
		n1=$(($n1%$hnd))
	fi
	# n1 <=99 and n1 >0
	if [ "$n1 " -lt "$twenty" ];then
		echo -n ${unit_place[$n1]} crore" "
	else
		#n1 >21 and n1 <=99
		echo -n ${tenth_place[$(($n1/10))]} ${unit_place[$(($n1%10))]} crore" "
	fi
	num=$(($num%$cr))
fi
if [ "$num" -ge "$lk" ];then
	n1=$(($num/$lk))
	# n1 <=99 and n1 >0
	if [ "$n1" -lt "20" ];then
		echo -n ${unit_place[$n1]} lakh" "
	else
		#n1 >21 and n1 <=99
		echo -n ${tenth_place[$(($n1/10))]} ${unit_place[$(($n1%10))]} lakh" "
	fi
	num=$(($num%$lk))
fi
if [ "$num" -ge "$th" ];then
	n1=$(($num/$th))
	# n1 <=99 and n1 >0
	if [ "$n1" -lt "20" ];then
		echo -n ${unit_place[$n1]} thousand" "
	else
		#n1 >21 and n1 <=99
		echo -n ${tenth_place[$(($n1/10))]} ${unit_place[$(($n1%10))]} thousand" "
	fi
	num=$(($num%$th))
fi
n1=$num
if [ "$n1" -ge "99" ];then
	#n1 is in 999 and $hnd inclusive
          echo -n ${unit_place[$(($n1/100))]} hundred" "
	  n1=$(($n1%$hnd))
fi
if [ "$n1" -lt "$twenty" ];then
		echo ${unit_place[$n1]}
else
		#n1 >21 and n1 <=99
	echo  ${tenth_place[$(($n1/10))]} ${unit_place[$(($n1%10))]}
fi