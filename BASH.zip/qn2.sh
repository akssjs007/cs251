#!/bin/bash
tbspace="    "
# myfn : function to return/print calculated the number of tabspaces to be given at the each level
myfn(){ 
	count=$1
	str=""
	 for ((i=0;i<count;i++))
		 do
			str+=$tbspace #string concatenation
		 done
	echo -e "${str}" #to print space with -e option
}
count_Integers(){
    # function to calculate the number of valid integers
    # invalid integers: asfa23.
    #                   23.23
    # valid sentences: 1233 . 
    #                  12314.
    local a=$1
    IFS=' '
    read -ra b <<< "$a"
    local count=0
    for elem in "${b[@]}"
    do
    if [[ $elem =~ ^-?[0-9]*$ ]];then
            ((count++))
    else
        if [[ $elem =~ ^-?[0-9]*[.]$ ]];then
                ((count++))
            fi
    fi
    done
    echo  "$count"
}
count_Sentences(){    
    # function to count the number of valid sentences
    # rules for valid sentences:
    #               must end with ". " if in the middle 
    #           or ends with "." in the end
    #  same rules but with "." replaced by "?" "!"
    local s=$1
    local c1=`echo   $s|grep -o '\. '|wc -l`
    local c2=`echo   $s|grep -o '\! '|wc -l`
    local c3=`echo   $s|grep -o '\? '|wc -l`
    local count=$(($c1+$c2+$c3))
    local len=${#s}
    if [[ ${s:$((len-1)):1} =~ ^[\.,\?,\!]$ ]];
    then
        ((count++))
    fi
    echo "$count"
}
checkSents()
{   
    # function to calculate recursively the no. of sentences a directory has 
    # assert that 1st argument is a directory
    # if asssertion fails then 0 is returned.
    local count=0
    local dir=$1
    for files in "$dir"/*
    do 
        if [ -f $files ];then 
            local f6=`cat "$files"`
            local f5=`count_Sentences "$f6"`
            count=$(($count+$f5))
        else 
            if [ -d $files ];then 
                local f5=`checkSents "$files"`
                count=$(($count+$f5))
            fi
        fi
    done
    echo "$count"
}
checkInts()
{
    # function to calculate recursively the no. of integers in the files and directory of 
    #  a  given directory has 
    # assert that 1st argument is a directory
    # if asssertion fails then 0 is returned.
    local count=0
    local dir=$1
    for files in "$dir"/*
    do 
        if [ -f $files ];then 
            local f6=`cat "$files"`
            local f5=`count_Integers "$f6"`
            count=$(($count+$f5))
        else 
            if [ -d $files ];then 
                local f5=`checkInts "$files"`
                count=$(($count+$f5))
            fi
        fi
    done
    echo "$count"   
}
# #######
directory() {
local we="$1"
local level="$2"
local nspace=`myfn $level`
	local c1=0
	local c2=0
	for file  in "$we"/*
	do
		if [ -f $file ];then
		local 	 fileData=`cat $file`
			local f1=`count_Sentences "$fileData"`
			local f2=`count_Integers  "$fileData"`
			 c1=$(($c1+$f1))
			 c2=$(($c2+$f2))
			 echo -e "${nspace}(F)${file##*/}-""$f1"-"$f2"
		else if [ -d $file ];then
			local f3=`directory "$file" "$(($level+1))"`
            echo "$f3"
            local f4=`checkInts "$file"`
            local f5=`checkSents "$file"`
            c1=$(($c1+$f5))
            c2=$(($c2+$f4))
			fi
		fi
	done
	nmspace=`myfn $(($level-1))`
	echo -e "${nmspace}(D)${we##*/}-""$c1"-"$c2"
}
read dir
if [ -d $dir ];then
    f=`directory "$dir" 1`
    echo "$f"
    exit 0
else
    echo "invalid input"
    exit 1
fi