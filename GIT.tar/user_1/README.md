# cs251
contains assignment for computing laboratory 1 @ IITK
