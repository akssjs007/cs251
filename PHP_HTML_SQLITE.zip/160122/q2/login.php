<?php
/**
 * Created by PhpStorm.
 * User: aks
 * Date: 2/4/18
 * Time: 5:52 AM
 */
class Mydb extends SQLite3{
    public function __construct()
    {
        $this->open('thumbs.db');
    }
    public function searchInTable($bankac)
    {

        $name=SQLite3::escapeString($bankac);
        $stmt='SELECT * FROM AC WHERE AC.EMAIL=\''.$name.'\'';
        $result=$this->query($stmt);
//        echo '<br>'.$this->lastErrorMsg();
        $count = 0;
        while($qw=$result->fetchArray((SQLITE3_ASSOC)))
        {
            $count++;
        }
        return ($count==1)?1:0;
    }
//    public function registerInTable($name,$)
    public function registerInTable($name,$email,$adrs,$mno,$acn,$acp){
        $name=SQLite3::escapeString($name);
        $adrs=SQLite3::escapeString($adrs);
        $email=SQLite3::escapeString($email);
        $mno=SQLite3::escapeString($mno);
        $acn=SQLite3::escapeString($acn);
        $acp=SQLite3::escapeString($acp);
        $vals='\''.$name.'\' '.'\''.$adrs.'\' '.'\''.$email.'\' ';
        $vals.=$mno.' '.$acn.' \''.$acp.'\'';
        $insert ="INSERT INTO AC(NAME,ADRS,EMAIL,MNO,ACN,ACP) VALUES(".$vals.")";
        $this->exec($insert);
        return 0;
    }
    public function verfiyRegister($name,$email,$adrs,$mno,$acn,$acp)
    {
        $count=$this->searchInTable($email);
        if($count==1)
            echo "User with the given email id already exists";
        else
        {    $this->registerInTable($name,$email,$adrs,$mno,$acn,$acp);
            echo "Registered the user.";}
    }
    public function canLogin($email,$pass)
    {
        $name=SQLite3::escapeString($email);
        $acp=SQLite3::escapeString($pass);
        $stmt='SELECT * FROM AC WHERE AC.EMAIL=\''.$name.'\' AND AC.ACP=\''.$acp.'\'';
        $result=$this->query($stmt);
        $count = 0;
        while($qw=$result->fetchArray((SQLITE3_ASSOC)))
        {
            $count++;
        }
        return ($count==1)?1:0;
    }
    public  function test($name)
    {
        echo "Kuch Bhi ".$name;
    }
    public function generateTable(){
        $dataRows = array();
        $dataColumns = array();
        $query = $this->query('SELECT ID,NAME,EMAIL,MNO,ACN,ADRS FROM AC');
        echo '<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Root Login Page</title>
    <style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
</style>
</head>
<body>';
        echo '<input id="btntest" type="button" value="Go to Login\Registration Page"  onclick=';
            echo '"location.href =\'index.html\'" />';
        echo '<table style="width:100%">';
        echo '<tr>
        <th>Sr. No.</th>
        <th>Name</th> 
        <th>Email Id</th>
        <th>Mobile No.</th>
        <th>Account No.</th>
        <th>Address</th>
      </tr>';
        while($row = $query->fetchArray(SQLITE3_ASSOC))
        {
            //add columns to array, checking if value exists
            $dataRows[]=$row;
            foreach($dataRows as $dataRow){
                echo '<td>'.$dataRow['ID'].'</td>';
                echo '<td>'.$dataRow['NAME'].'</td>';
                echo '<td>'.$dataRow['EMAIL'].'</td>';
                echo '<td>'.$dataRow['MNO'].'</td>';
                echo '<td>'.$dataRow['ACN'].'</td>';
                echo '<td>'.$dataRow['ADRS'].'</td>';
                // etc.
            }
            echo '</tr>';

        }
        echo '</table>';
        echo '</body> </html>';
    }
}
$db=new Mydb();
$email=$_POST['uname'];
$acp=$_POST['acp'];
if($db->canLogin($email,$acp) == 1)
    if($email==='ankitaks@c.com') {

        $db->generateTable();
    }
    else
    echo "User Exists (can't login till further updates)";
else
    echo "Invalid Credentials";