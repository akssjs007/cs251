<?php
/**
 * Created by PhpStorm.
 * User: aks
 * Date: 2/4/18
 * Time: 5:52 AM
 */

class Mydb extends SQLite3{
    public function __construct()
    {
        $this->open('thumbs.db');
    }
    public function searchInTable($bankac)
    {

        $name=SQLite3::escapeString($bankac);
        $stmt='SELECT * FROM AC WHERE AC.EMAIL=\''.$name.'\'';
        $result=$this->query($stmt);
//        echo '<br>'.$this->lastErrorMsg();
        $count = 0;
        while($qw=$result->fetchArray((SQLITE3_ASSOC)))
        {
            $count++;
        }
        return ($count==1)?1:0;
    }
//    public function registerInTable($name,$)
    public function registerInTable($name,$email,$adrs,$mno,$acn,$acp){
        $name=SQLite3::escapeString($name);
        $adrs=SQLite3::escapeString($adrs);
        $email=SQLite3::escapeString($email);
        $mno=SQLite3::escapeString($mno);
        $acn=SQLite3::escapeString($acn);
        $acp=SQLite3::escapeString($acp);
        $vals='\''.$name.'\', '.'\''.$adrs.'\', '.'\''.$email.'\', ';
        $vals.=$mno.', '.$acn.'\','.$acp.'\', 0';
        $insert ="INSERT INTO AC VALUES('$name','$adrs','$email','$mno','$acn','$acp','0')";
        $this->query($insert);
//        return 0;
    }
    public function verfiyRegister($name,$email,$adrs,$mno,$acn,$acp)
    {
        $count=$this->searchInTable($email);
        if($count==1){
//            echo "User with the given email id already exists";
            return 0;}
        else
        {    $this->registerInTable($name,$email,$adrs,$mno,$acn,$acp);
//            echo "Registered the user.";
            return 1;
        }
    }
    public  function test($name)
    {
        echo "Kuch Bhi ".$name;
    }
}
class validation
{
    public static function verifyPassword($pass1,$pass2)
    {
        if(!($pass1===$pass2))
            return 0;
        else
        {
            $letters = '/^[0-9a-zA-Z]+$/';
            return preg_match_all($letters,$pass1);
        }

    }
    public static function verifyName($name)
    {
        if($name =="")
            return 0;
        else
        {
            $letters = '/^[ a-zA-Z]+$/';
            return preg_match_all($letters,$name);
        }

    }

}
//
$name=$_POST['name'];
$email=$_POST['email'];
$adrs=$_POST['adrs'];
$mno=$_POST['mno'];
$acn=$_POST['acn'];
$acp=$_POST['acp'];
$acp2=$_POST['acp2'];
$db=new Mydb();
//echo '<br>'.$name;
//echo '<br>'.$acp;
//echo '<br>'.$adrs;
//echo '<br>'.$email;
//echo '<br>'.$acn;
//echo '<br>'.$mno;
//echo '<br>'.$db->searchInTable($email);
//echo '<br>'.;
echo '<br>';

if( $db->lastErrorCode()==='0')
    echo $db->lastErrorMsg();
else
    if(validation::verifyPassword($acp,$acp2))
    {
        if(validation::verifyName($name))
        {
               $rs=$db->verfiyRegister($name,$email,$adrs,$mno,$acn,$acp);
               if($rs==0)
               {
                   echo "User with the email already exists";
               }
               else
                   echo "Registration Successfull";

        }
        else
            echo "Kindly check your name.";
    }
    else
        echo "Kindly check both the passwords.";
?>

