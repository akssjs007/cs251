// --- improved version ------------------
#include <stdio.h>
#include<stdlib.h>
#include<sys/time.h>
#include<fcntl.h>
#include<pthread.h>
#include<string.h>
#include <math.h>
#define MAX_THREADS 64
#define START_INDEX 1001
#define SIZE 10000
#define USAGE_EXIT(s) do{ \
                             printf("Usage: %s <acc_file.txt> <txn_file.txt> <# of txns> <# of threads> \n %s\n", argv[0], s); \
                            exit(-1);\
                    }while(0);

#define TDIFF(start, end) ((end.tv_sec - start.tv_sec) * 1000000UL + (end.tv_usec - start.tv_usec))
struct acc{ // structure to contain account related information.
  double bal;
  //int prev_trans_id;
  struct trx* trans;
};
struct trx{//structure to contain transaction related info.
  int txn_id;
	double amt;
  struct trx* next;
};
struct thread_param{//thread related parameters.
  pthread_t tid;
  struct acc* acn;
  int* ids_mod;
  int size_ids;
  int skip;
  int i;
};
typedef struct acc AC;
typedef struct trx txn;
void actual_Calc(AC* acn,txn* trans,int id) //id == acc no-START_INDEX
{
  if(trans==NULL) {
      //Any suitable rounding method could be used here to round curr->bal.
      return;
  }
  else
  {
    AC* curr = (acn+id);
    switch(trans->txn_id)
    {
      case 1:
            curr->bal = curr->bal + .990*((trans->amt));
            break;
      case 2:
            curr->bal =curr->bal - 1.010*((trans->amt));
            break;
      case 3:
            curr->bal = (curr->bal)*1.0710;
            break;
    }
    actual_Calc(acn,trans->next,id);
    free(trans);
    return;
  }
}
void functor(AC* ac,int index)//wrapper for actual_Calc
{
    actual_Calc(ac,(ac+index)->trans,index);
    return;
}
void* calculateIt(void *arg)
{
    struct thread_param * params =(struct thread_param *) arg;
    int  i = params->i;
    int skip=params->skip;
    int sparsSize=params->size_ids;
    for(int j = i;j<sparsSize;)
    {
      functor(params->acn,params->ids_mod[j]);
      j = j + skip;
    }
    return NULL;
}
void insertTxn(AC *acn,int src_id,int dest_id,int txn_code,double amt)
{ if(acn != NULL)
  {
    if(txn_code < 4 && txn_code >0)
    {
        txn* curr =  (acn+src_id)->trans;
        txn* nw=(txn*) malloc(sizeof(txn));
        nw->next=NULL;
        nw->amt=amt;
        nw->txn_id=txn_code;   
        txn_code = 0; 
        if(curr==NULL)
        {
          (acn+src_id)->trans=nw;
          return;
        }   
        else
        {
          while(curr->next!=NULL)
          {
            curr= curr->next;
          }
          curr->next=nw;
          return;          
         }
    }
    else if(txn_code == 4)
    {
        insertTxn(acn,src_id,dest_id,2,amt);//withdraw from src_id 
        insertTxn(acn,dest_id,src_id,1,amt);//deposit in dest_id;
        return;
    }
  }
  return;
}
int main(int argc,char** argv)
{
      struct timeval start, end; 
	   if(argc != 5){
            USAGE_EXIT("not enough parameters");
      }  
     FILE* acc_file= fopen(argv[1],"r");
     if(acc_file==NULL)
     {
       printf("Unable to read the specified account file\n");
       exit(-1);
     }
    FILE* txn_file =fopen(argv[2],"r");
    if(txn_file==NULL)
    {
      printf("Unable to read the specified transaction file\n");
      exit(-1);
    }
    ///files can be read.
    int nThreads=atoi(argv[4]);
    if(nThreads <=0 || nThreads >MAX_THREADS)
    {
      printf("ThreadNumberOutOfRange Exception ");
      exit(-1);
    }
    int nTrans =atoi(argv[3]);
    if(nTrans <0 )
    {
      printf("TransactionNumberOutOfRange Exception ");
      exit(-1);
    }
    AC* acns =(AC*)malloc(SIZE*sizeof(AC));
    if(acns == NULL)
    {
      printf("Not enough memory!\n");
      exit(0);
    }
    for(int i =0;i<SIZE;i++)
    {
      int id;
      double bal;
      fscanf(acc_file,"%d %lf",&id,&bal);
      (acns+i)->bal=bal;
    }
    if(nTrans == 0)
    {
        FILE* tmp = fopen("final_acc.txt","w");
            for(int i = 0; i< SIZE;i++)            
              fprintf(tmp,"%d %.2lf\n",(i+START_INDEX),(acns+i)->bal);
        fclose(tmp);
        free(acns);
        exit(0);
    }
    //All parameters fine. Now make the data Structure
    char* visited = (char*)calloc(SIZE+1,sizeof(char));
    if(visited == NULL)
    {
      printf("Not enough memory!\n");
      exit(0);
    }
    for (int i=0;i<nTrans;i++)//To fully load the transactions into memory(in the dataStructure formed).
    {
      int sNo,txnCode,ac1,ac2;
      double amt;
      txnCode= 0;
      fscanf(txn_file,"%d %d %lf %d %d",&sNo,&txnCode,&amt,&ac1,&ac2);
      insertTxn(acns,ac1-START_INDEX,ac2-START_INDEX,txnCode,amt);
      visited[ac1-1000]=1;
      visited[ac2-1000]=1;
    }
    ///////////////////////////////
    int* ids_modified=(int*)malloc(SIZE*sizeof(int));
    int sparseSize =0;
    for (int j = 1; j <= SIZE; ++ j) {
        if(visited[j] == 1)
        {
            ids_modified[sparseSize++]=j-1;
        }
    }
    free(visited);
    fclose(acc_file);
    fclose(txn_file);
    //file stream closed
    struct thread_param* params;
    params = malloc(nThreads*sizeof(struct thread_param));
    bzero(params,nThreads*sizeof(struct thread_param));
    //Use of threading starts here
    gettimeofday(&start, NULL);
    for (int ctr=0;ctr<nThreads;ctr++)
    {
      (params+ctr)->skip=nThreads;
      (params+ctr)->ids_mod=ids_modified;
      (params+ctr)->size_ids=sparseSize;
      (params+ctr)->acn=acns;
      (params+ctr)->i = ctr;
      if(pthread_create(&(params+ctr)->tid,NULL,calculateIt,(params+ctr))!=0)
        {
          perror("pthread_create");
          exit(-1);
        }      
    }
   for(int ctr=0;ctr < nThreads;ctr++){
   struct thread_param* paramq = params +ctr;
   pthread_join(paramq->tid,NULL);
   }/*threading done.           End the timer.*/
   gettimeofday(&end, NULL);
   printf("Time taken = %ld microsecs\n", TDIFF(start, end));
    free(ids_modified);
    FILE* tmp = fopen("final_acc.txt","w");
    if(tmp == NULL)
    {
        printf("Error:Unable to write the O/P file");
        exit(-1);
    }
    for(int i = 0; i< SIZE;i++)
    {
        fprintf(tmp,"%d %.2lf\n",(i+START_INDEX),(acns+i)->bal);
    }
 fclose(tmp);
 free(acns);
 free(params);
    return 0;
}
