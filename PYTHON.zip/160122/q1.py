#! /usr/bin/python3 
"""
compatible with python >=3
isInValid: assumes that no fractional number is sent to it
    :argument num,base
    :num: the number to be checked
    :base: the base in which the number is to checked
    :returns : -1 if the base is invalid
             :0 if the number in the given base is a valid representation
             :1 if the number in the given base is an invalid representation
"""
def isInValid(num,base):
    if base < 2 or base > 36:
        return -1
    if base > 10:
        # c=ord('A')
        # d=c+(base-11)
        num=str(num).strip().upper()
        f=1
        if num[0] != '-':
            f=0
        for i in range(f,len(num)):
            if(num[i].isdigit()):
                continue
            else:
                diff=ord(num[i])-ord('A')
                if not (0<= diff and diff <= (base-10)):
                    # print ("index ",i)
                    return 1
        return 0
    else:
        """
        Case: base <= 10
              Contains only digits
        """
        f=1
        if num[0] != '-':
            f=0
        num=str(num).strip()
        for i in range(f,len(num)):
            if(num[i].isdigit()):
                if ( (ord(num[i])-ord('0')) >= base):
                    return 1
            else:
                return 1
        return 0
"""
convert: assumes that both the base and the number is valid
"""
def conVert(base,num):
    num=str(num).strip()
    sign=3
    tmp=num.split('-')
    l=len(tmp)
    if l >= 1:
        if l==1:
            sign=1 if tmp[0]=='' else 3
        else:
            if l==2:
                sign=1 if tmp[0]=='' else -2
            else:
                sign =-2
    else:
        sign=3
    fract=0
    tmp=num.split('.')
    l=len(tmp)
    if l >1:
        fract= 1 if l==2 else -2
    else:
        fract=0    
    if fract>=0 and sign > 0:
        "Valid with sign and decimal"
        if sign==1:
            num=num.replace('-',' ',2).strip()
        numq=num.split('.')
        # print (numq)
        befDot=0
        if (numq[0]==''):
              if (len(numq)==1):
                  return (-5,-5,-5,-5)
              befDot=0
        else:
            if  not isInValid(numq[0],base):
                befDot=convert(base,numq[0],0)
            else:
                    return (-1,-1,-1,-1)
        afterDot=0
        if fract:
            if (numq[1]==''):
              return (-4,-4,-4,-4)
            else:
                if not isInValid(numq[1],base):
                    afterDot=convert(base,numq[1],1)
                    return (sign-2,fract,befDot,afterDot)
                else:
                    return (-2,-2,-2,-2)
        return (sign-2,fract,befDot,afterDot)
    else:
        return (-3,-3,-3,-3)
def convert(base,num,float_flag):
    finVal=0
    num=str(num)
    num=num.strip()
    sign=-1
    offset=1
    if not float_flag:
        num=num[::-1]
        sign =1
        offset=0
    for i in range(0,len(num)):
            t=0
            if num[i].isdigit():
                t=ord(num[i])-ord('0')
            else:
                t=ord(num[i])-ord('A')+10
            finVal+=t*(base**(sign*(i+offset)))
    return finVal
def main():
    import sys
    if (len(sys.argv)!=3):
        print ("invalid input")
    else:
        num=str(sys.argv[1]).strip().upper()
        base=int(sys.argv[2].strip())
        if base<2:
            print ("Invalid input")
        else:
            "Every thing is valid"
            (sign,fract,num1,num2)=conVert(base,num)
            if fract <0:
                print("invalid input")
            else:
                finalVal=sign*(num1+fract*num2)
                if (sign*finalVal) > 999999999:
 		    print ("out of range output")
                else:
                    print (finalVal)
                    
if __name__=='__main__':
    main()
